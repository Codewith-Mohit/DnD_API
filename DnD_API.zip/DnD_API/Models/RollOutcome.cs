﻿namespace DnD_API.Models
{
    public class RollOutcome
    {
        public bool Hit { get; set; }
        public bool Critical { get; set; }
        public string Message { get; set; }
        public int DamageDealt { get; set; }
        public int TargetRemainingHp { get; set; } 
    }
}