﻿namespace DnD_API.Models
{
    public class ActionResult 
    { 
        public string RunId { get; set; } 
        public string Event { get; set; } 
        public DiceRollResult Roll { get; set; } 
        public RollOutcome Outcome { get; set; } }
}
