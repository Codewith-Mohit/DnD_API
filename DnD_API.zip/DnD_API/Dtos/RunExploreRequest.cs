﻿namespace DnD_API.Dtos
{
    public class RunExploreRequest
    {
        // future: direction; for MVP, simply moves to next room
    }
}
