﻿namespace DnD_API.Dtos
{
    public class RunCreateDto
    {
        public Guid CharacterId { get; set; }
        public int? Seed { get; set; }
    }
}
