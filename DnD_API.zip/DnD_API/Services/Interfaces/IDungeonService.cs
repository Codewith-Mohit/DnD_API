﻿namespace DnD_API.Services.Interfaces
{
    public class IDungeonService
    {
    }
}
